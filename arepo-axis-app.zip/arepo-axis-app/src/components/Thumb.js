import React from "react";
import { Text, View } from "react-native";
import { CATEGORY_TINT } from "../data/mockData";

export default function Thumb({ emoji, category, size = 44 }) {
  return (
    <View
      style={{
        width: size, height: size, borderRadius: 12,
        backgroundColor: CATEGORY_TINT[category] || "#EFEDE6",
        alignItems: "center", justifyContent: "center",
      }}
    >
      <Text style={{ fontSize: size * 0.5 }}>{emoji}</Text>
    </View>
  );
}
